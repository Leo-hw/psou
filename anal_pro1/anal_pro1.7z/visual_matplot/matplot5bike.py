# kaggle dataset 중에서 자전거 공유 데이터fh 시각화

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

plt.style.use('ggplot')         # R의 ggplot 스타일을 사용

# 탐색적 분석(EDA)
train = pd.read_csv('https://raw.githubusercontent.com/pykwon/python/master/data/train.csv', parse_dates=['datetime'])      # parse_dates = datetime 형식으로 읽기

print(train.shape)
print(train.info())
print(train.columns)
pd.set_option('display.max_columns', 500) # 생략 없이 전체 보기.
print(train.head(3)) 
print(train.temp.describe())        # temp column 컬럼에  대한 요약 통계량
print(train.isnull().sum())     # null 이 포함된 column 을 확인

# pip install missingno
import missingno as msno
msno.matrix(train, figsize=(12,5))
plt.show()






